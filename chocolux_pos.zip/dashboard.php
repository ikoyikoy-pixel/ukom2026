<?php include 'config.php';
if(!isset($_SESSION['user'])) header("Location: login.php");
?>
<h1>Dashboard</h1>
<a href="products.php">Kelola Produk</a><br>
<a href="profile.php">Edit Profil</a><br>
<a href="logout.php">Logout</a>
