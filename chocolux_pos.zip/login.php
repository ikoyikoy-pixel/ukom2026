<?php include 'config.php';

if(isset($_POST['login'])){
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email=?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if($user && password_verify($password, $user['password'])){
        $_SESSION['user'] = $user;
        header("Location: dashboard.php");
    } else {
        echo "Login gagal";
    }
}
?>
<form method="POST">
<h2>Login</h2>
<input name="email"><br>
<input type="password" name="password"><br>
<button name="login">Login</button>
</form>
