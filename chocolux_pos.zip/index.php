<?php include 'config.php'; ?>
<!DOCTYPE html>
<html>
<head>
<title>ChocoLux POS</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-dark text-white text-center p-5">
<h1>Welcome to ChocoLux POS</h1>
<a href="login.php" class="btn btn-light">Login</a>
<a href="register.php" class="btn btn-warning">Register</a>
</body>
</html>
