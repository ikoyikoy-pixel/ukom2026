<?php include 'config.php';

if(isset($_POST['register'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $stmt = $pdo->prepare("INSERT INTO users (name,email,password) VALUES (?,?,?)");
    $stmt->execute([$name,$email,$password]);

    header("Location: login.php");
}
?>
<form method="POST">
<h2>Register</h2>
<input name="name" placeholder="Nama"><br>
<input name="email" placeholder="Email"><br>
<input type="password" name="password" placeholder="Password"><br>
<button name="register">Daftar</button>
</form>
