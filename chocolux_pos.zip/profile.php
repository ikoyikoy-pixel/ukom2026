<?php include 'config.php';
if(!isset($_SESSION['user'])) header("Location: login.php");

if(isset($_POST['update'])){
    $name = $_POST['name'];
    $id = $_SESSION['user']['id'];

    $stmt = $pdo->prepare("UPDATE users SET name=? WHERE id=?");
    $stmt->execute([$name,$id]);
    echo "Update berhasil";
}
?>
<form method="POST">
<input name="name" value="<?=$_SESSION['user']['name']?>">
<button name="update">Update</button>
</form>
