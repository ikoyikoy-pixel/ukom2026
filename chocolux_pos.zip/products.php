<?php include 'config.php';
if(!isset($_SESSION['user'])) header("Location: login.php");

if(isset($_POST['add'])){
    $stmt = $pdo->prepare("INSERT INTO products (name,price,stock) VALUES (?,?,?)");
    $stmt->execute([$_POST['name'],$_POST['price'],$_POST['stock']]);
}

if(isset($_GET['delete'])){
    $stmt = $pdo->prepare("DELETE FROM products WHERE id=?");
    $stmt->execute([$_GET['delete']]);
}

$products = $pdo->query("SELECT * FROM products")->fetchAll();
?>
<h2>Produk</h2>
<form method="POST">
<input name="name" placeholder="Nama">
<input name="price" placeholder="Harga">
<input name="stock" placeholder="Stok">
<button name="add">Tambah</button>
</form>

<table border="1">
<?php foreach($products as $p): ?>
<tr>
<td><?=$p['name']?></td>
<td><?=$p['price']?></td>
<td><?=$p['stock']?></td>
<td><a href="?delete=<?=$p['id']?>">Hapus</a></td>
</tr>
<?php endforeach; ?>
</table>
